﻿namespace xServer.Core.Data
{
    public static class DownloadAndExecute
    {
        public static string URL { get; set; }
        public static bool RunHidden { get; set; }
    }
}
